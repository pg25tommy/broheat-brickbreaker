#pragma once

#include <vector>
#include <memory>
#include <iostream>
#include <functional>

#define LOG(X) std::cout << X
#define LOG_LINE(X) std::cout << X << std::endl
